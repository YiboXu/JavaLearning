### Mycat连接MySQL 8时的注意事项
https://www.linuxidc.com/Linux/2019-07/159593.htm




